/*
Author: Aakash Venkataraman
Class: ECE4122 or ECE6122
Last Date Modified: 20-11-2022

Description:
This program acts as a server and behaves as mentioned in the problem, it stores messages received from different clients in log file.
*/

#include <SFML/Network.hpp>
#include <iostream>
#include <vector>
#include <fstream>
#include <ctime>
#include <regex>
#include <list>
#include <string>

int main(int argc, char* argv[])   //Accepts IP address and port number as command line arguments 
{
    int port;
    bool valid = false;
    std::string port_str;
    port_str = argv[2];
    int port_integer = 0;
    for (int i = 0; i < port_str.length(); i++)
    {
        if (isdigit(port_str[i]) && port_str[i] >= 0)
        {
            valid = true;
            port_integer = stoi(port_str);
        }
        else
        {
            valid = false;
            std::cout << "Invalid command line argument detected: < " << argv[2] << " >" << std::endl;
            std::cout << "Please check your values and press any key to end the program!" << std::endl;
            std::cin.ignore(1000, '\n');
        }
    }

    if (valid && port_integer >= 61000 && port_integer <= 65535)
    {
        port = port_integer;
        valid = true;
    }
    else
    {
        valid = false;
        std::cout << "Invalid command line argument detected: < " << argv[2] << " >" << std::endl;
        std::cout << "Please check your values and press any key to end the program!" << std::endl;
        std::cin.ignore(1000, '\n');
    }

    if (valid)
    {
        std::ofstream outfile;
        outfile.open("server.log.txt");

        std::size_t received;
        // Server socket accepts new connections
        sf::TcpListener listener;

        // Listens to the given port for incoming connections
        if (listener.listen(port) != sf::Socket::Done)
            return 1;
       
        // List is created to store the future clients
        std::list<sf::TcpSocket*> clients;
        std::list<sf::TcpSocket*> removeclients;
        std::list<sf::TcpSocket*>::iterator it;
        //A selector is created
        sf::SocketSelector selector;
        selector.add(listener);

        char in[128];
        sf::Packet receivePacket;        
        
        while (1)
        {
            if (selector.wait())
            {
                if (selector.isReady(listener))
                {
                    sf::TcpSocket* client = new sf::TcpSocket;
                    if (listener.accept(*client) != sf::Socket::Done)
                        return 1;
                    else
                    {
                        time_t now = time(0);
                        char* dt = ctime(&now);
                        *std::remove(dt, dt + strlen(dt), '\n') = '\0';
                        outfile << dt << "::" << (*client).getRemoteAddress() << ":: Connected" << std::endl;
                        selector.add(*client);
                        clients.push_back(client);
                    }
                }
                if (!clients.empty())
                {
                    // The listener socket is not ready, test all other sockets (the clients)
                    for (it = clients.begin(); it != clients.end(); ++it)
                    {
                        sf::TcpSocket& client = **it;
                        bool found_client = (std::find(removeclients.begin(), removeclients.end(), *it) != removeclients.end());
                        if (!selector.isReady(**it))
                            continue;
                        if (found_client)
                            continue;
                        if (selector.isReady(client))
                        {
                            if (client.receive(in, sizeof(in), received) == sf::Socket::Done)
                            {
                                time_t now = time(0);
                                char* dt = ctime(&now);
                                *std::remove(dt, dt + strlen(dt), '\n') = '\0';
                                outfile << dt << "::" << client.getRemoteAddress() << "::" << in << std::endl;
                                
                            }
                            else if (client.receive(in, sizeof(in), received) == sf::Socket::Disconnected)
                            {
                                time_t now = time(0);
                                char* dt = ctime(&now);
                                *std::remove(dt, dt + strlen(dt), '\n') = '\0';
                                outfile << dt << "::" << client.getRemoteAddress() << "::" << " Disconnected" << std::endl;
                                
                                removeclients.push_back(*it);
                                selector.remove(**it);
                            }
                        }
                    }
                }
            }
        }
        outfile.close();
    }
}



