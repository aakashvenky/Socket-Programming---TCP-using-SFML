/*
Author: Aakash Venkataraman
Class: ECE4122 or ECE6122
Last Date Modified: 20-11-2022

Description:
This program acts as a client, that waits for user to enter a message and sends it to the server.
*/

#include <SFML/Network.hpp>
#include <iostream>
#include <string>


int main(int argc, char* argv[])     //Accepts IP address and port number as command line arguments 
{
    int port;
    bool valid = false;
    std::string port_str;
    port_str = argv[2];
    int port_integer = 0;
    for (int i = 0; i < port_str.length(); i++)
    {
        if (isdigit(port_str[i]) && port_str[i] >= 0)
        {
            valid = true;
            port_integer = stoi(port_str);
        }
        else
        {
            valid = false;
            std::cout << "Invalid command line argument detected: < " << argv[2] << " >" << std::endl;
            std::cout << "Please check your values and press any key to end the program!" << std::endl;
            std::cin.ignore(1000, '\n');
        }
    }

    if (port_integer >= 61000 && port_integer <= 65535 && valid)
    {
        port = port_integer;
        valid = true;
    }
    else
    {
        valid = false;
        std::cout << "Invalid command line argument detected: < " << argv[2] << " >" << std::endl;
        std::cout << "Please check your values and press any key to end the program!" << std::endl;
        std::cin.ignore(1000, '\n');
    }
    if (valid)
    {
        sf::IpAddress server;
        do
        {
            server = argv[1];
        } while (server == sf::IpAddress::None);

        // Socket created for communicating with the server
        sf::TcpSocket socket;

        // Connected to the server
        if (socket.connect(server, port) != sf::Socket::Done)
        {
         
            std::cout << "Failed to connect to the server at " << server << " on " << port << std::endl;
            std::cout << "Please check your values and press any key to end program!";
            return 1;
        }
        /*else
        {
            //std::cout << "Connected to server " << server << std::endl;
        }*/

        char message[128];
        while (1)
        {
            std::cout << "Please enter the message:" << " ";
            std::cin.getline(message, sizeof(message));
            if (strcmp("quit", message) == 0)
            {
                socket.disconnect();
                exit(0);
            }
            if (socket.send(message, sizeof(message)) != sf::Socket::Done)
                return 1;
            

        }
    }
}
